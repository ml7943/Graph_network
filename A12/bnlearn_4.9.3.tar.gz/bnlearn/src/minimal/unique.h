#ifndef R_UNIQUE_HEADER
#define R_UNIQUE_HEADER

SEXP unique(SEXP array);
SEXP dupe(SEXP array);

#endif
