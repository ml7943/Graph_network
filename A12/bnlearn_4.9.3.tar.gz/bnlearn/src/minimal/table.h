#ifndef TABLE_HEADER
#define TABLE_HEADER

SEXP minimal_table(SEXP dataframe, SEXP missing);

#endif
